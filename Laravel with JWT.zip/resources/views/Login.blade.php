<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="UTF-8"/>
        <title>{{$pageTitle}}</title>
        <meta name="csrf-token" content="{{ csrf_token() }}"/>
        <link rel="stylesheet" href="{{asset('css/app.css')}}"/>
    </head>
    <body>
        <div class="container">
            <form action="/login-info" method="post" accept-charset="UTF-8"> 
                @csrf
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-2">Username</div>
                <div class="col-md-4 form-group">
                    <input type="text" value="{{ old('username') }}" name="username" autocomplete="off" autofocus required class="form-control">
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
        
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-2">Password</div>
                <div class="col-md-4 form-group">
                    <input type="password" value="{{ old('userpass') }}" name="userpass" autocomplete="off" required class="form-control">
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
        
            <div class="row">
                <div class="col-md-4">&nbsp;</div>
                <div class="col-md-4 form-group">
                    <input type="submit" value="submit" class="btn btn-success">
                </div>
                <div class="col-md-4">&nbsp;</div>
            </div>
            </form>
        </div>
        <script src="{{ asset('js/app.js')}}"></script>
    </body>
</html>
