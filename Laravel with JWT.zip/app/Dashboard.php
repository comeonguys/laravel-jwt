<?php
namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;
class Dashboard extends Model
{
    public function storepair($pairname)
    {
        $check_login=DB::Insert('insert into bittrex(TRADE_PAIR)values(?)',[$pairname]);
        return count($check_login);
    }
    
    public function apidata()
    {
        return DB::Select('select * from bittrex');
    }
}