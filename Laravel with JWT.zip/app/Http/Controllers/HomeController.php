<?php

namespace App\Http\Controllers;

use App\Home;
use Illuminate\Http\Request;
use Validator;
use Session;
use Illuminate\Support\Facades\Input;
use Response;
use Illuminate\Http\Response as HttpResponse;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class HomeController extends Controller
{
    protected $callHomemodel;
    protected $user;
    
    public function __construct() {
        $this->callHomemodel = new Home();
       //  $this->user = JWTAuth::parseToken()->authenticate();
    }
    public function index()
    {
        return view('Login')->with('pageTitle','Login');
    }

    public function store(Request $request)
    {
        $uname = $request->get('username');
        $upass = $request->get('userpass');
        $validator = Validator::make($request->all(),[
            'username' => 'required|max:50|min:4',
            'userpass' => 'required'
        ],[
            'username.required' => 'Username is required',
            'userpass.required' => 'Password is required'
        ])->validate();
        
        if($validator) {
            if($this->callHomemodel->checklogin($uname, $upass)) {
                Session::put('admin',$uname);
                return redirect('employee/dashboard')->with('pageTitle','Dashboard');
            }
            else {
                return redirect()->back();
            }
        }
        
    }
    
    public function apidata(Request $request)
    {
          $credentials= Input::only('email', 'password');
        $token = null;
 
        if (!$token = JWTAuth::attempt($credentials)) {
            return Response::json(['success'=>'','error'=>'invalid']);//false, HttpResponse::HTTP_UNAUTHORIZED
        }
        else
        {
           return Response::json([
          'status'=>'success',
          'error'=>'',
          'data'=>[
              'email' => $credentials
          ],
        'token' => $token,
        'expires' => JWTAuth::factory()->getTTL() * 60, ]);
        }
 
    }
}
