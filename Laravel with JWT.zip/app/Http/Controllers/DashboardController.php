<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Session;
use Validator;
use App\Dashboard;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Response;

class DashboardController extends Controller
{
    protected $dash;
    public function __construct() {
        $this->dash = new DashboardController();
        if(Session::get('admin')=='')
        {
            return redirect('/employee/logout');
        }
    }
    
    public function index()
    {
        return view('employee/_dashboard')->with('pageTitle','Dashboard');
    }

    public function store(Request $request)
    {
        $crytopair = $request->get('crytopair');
        
        $validator = Validator::make($request->all(),[
            'exchange' => 'required',
            'crytopair' => 'required'
        ],[
            'username.required' => 'Username is required',
            'userpass.required' => 'Password is required'
        ])->validate();
        
        if($validator)
        {
            $this->dash->storepair($crytopair);
        }
    }
    
    public function apidata()
    {
        $get_api_deata=$this->dash->apidata();
        return Response::json(['success'=>true,'error'=>'','data'=>$get_api_deata]);
    }
    
     public function logout()
    {
       Session::flush();    // remove all session
       // Session::forget('key'); Remove specific variable
       return redirect('/login-info');
    }
}
