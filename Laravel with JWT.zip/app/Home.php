<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;
class Home extends Model
{
    public function checklogin($uname,$upass)
    {
        $check_login=DB::Select('select * from employee where username=? and passpharse=?',[$uname,$upass]);
        return $check_login;
    }
    
      public function apidata()
    {
        $get_api_deata=DB::Select('select * from bittrex');
        return $get_api_deata;
    }
}
