<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo e($pageTitle); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"/>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-3">&nbsp;</div>
                <div class="col-md-6 text-center"><h3>WELCOME <?php echo strtoupper(Session::get('admin')); ?></h3></div>
                <div class="col-md-3 text-center">
                    <a class="btn btn-primary" href="/employee/logout">Logout</a>            
                </div>
            </div>
            <div class="row">&nbsp;</div>
            <form action="employee/dashboard" method="post" accept-charset="UTF-8">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-3">Choose Exchange</div>
                <div class="col-md-4 form-group">
                    <select class="form-control" required name="exchnage">
                        <option value=""></option>
                        <option value="Bittrex">Bittrex</option>
                        <option value="Binanace">Binanace</option>
                        <option value="Poloniex">Poloniex</option>
                    </select>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
            
             <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-3">Crypto-Pair</div>
                <div class="col-md-4 form-group">
                    <input type="text" value="" name="crytopair" autocomplete="off" required class="form-control"/>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
            
             <div class="row">
                <div class="col-md-4">&nbsp;</div>
                <div class="col-md-4 form-group">
                    <input type="submit" value="submit" class="btn btn-success">
                </div>
                <div class="col-md-4">&nbsp;</div>
            </div>
            </form>
        </div>
    </body>
</html>
