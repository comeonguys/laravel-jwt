<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8"/>
        <title><?php echo e($pageTitle); ?></title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"/>
    </head>
    <body>
        <div class="container">
            <form action="/login-info" method="post" accept-charset="UTF-8"> 
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-2">Username</div>
                <div class="col-md-4 form-group">
                    <input type="text" value="<?php echo e(old('username')); ?>" name="username" autocomplete="off" autofocus required class="form-control">
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
        
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-2">Password</div>
                <div class="col-md-4 form-group">
                    <input type="password" value="<?php echo e(old('userpass')); ?>" name="userpass" autocomplete="off" required class="form-control">
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
        
            <div class="row">
                <div class="col-md-4">&nbsp;</div>
                <div class="col-md-4 form-group">
                    <input type="submit" value="submit" class="btn btn-success">
                </div>
                <div class="col-md-4">&nbsp;</div>
            </div>
            </form>
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
